<div class="modal fade" id="student-delete-details" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Delete Student</h4>
      </div>
      <div class="form-horizontal">
        <form class="" action="" method="post">
          <input type="hidden" name="studentid" id="studentid">
          <div class="modal-body">
            <strong>Are you sure?</strong>
          </div>
          <div class="modal-footer">
            <input type="submit" class="btn btn-danger submitbtn" value="Delete">
          </div>
        </form>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
